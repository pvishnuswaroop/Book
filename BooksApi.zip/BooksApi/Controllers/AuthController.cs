﻿using BooksApi.Data;
using BooksApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BooksApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AuthController : ControllerBase
	{
		private readonly AppDbContext _context;
		private readonly IConfiguration _config;

		public AuthController(AppDbContext context, IConfiguration config)
		{
			_context = context;
			_config = config;
		}
		[HttpPost("register")]
		public async Task<IActionResult> Register([FromBody] UserDto userdto)
		{
			if (await _context.Users.AnyAsync(u => u.Username == userdto.Username))
			{
				return Conflict("Username already exists.");
			}

			var user = new User
			{
				Username = userdto.Username,
				Password = BCrypt.Net.BCrypt.HashPassword(userdto.Password), // Hash the password
				Role = userdto.Role ?? "User" // Default role is "User"
			};

			_context.Users.Add(user);
			await _context.SaveChangesAsync();
			return Ok("User registered successfully.");
		}
		[HttpPost("login")]
		public async Task<IActionResult> Login([FromBody] UserLogin userlogin)
		{
			var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == userlogin.Username);
			if (user == null || !BCrypt.Net.BCrypt.Verify(userlogin.Password, user.Password))
			{
				return Unauthorized("Invalid username or password.");
			}

			var token = GenerateJwtToken(user);
			return Ok(new { Token = token });
		}

		// Generate JWT token
		private string GenerateJwtToken(User user)
		{
			var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
			var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

			var claims = new[]
			{
			new Claim(JwtRegisteredClaimNames.Sub, user.Username),
			new Claim("role", user.Role),
			new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
		};

			var token = new JwtSecurityToken(
				_config["Jwt:Issuer"],
				_config["Jwt:Issuer"],
				claims,
				expires: DateTime.Now.AddMinutes(30),
				signingCredentials: credentials);

			return new JwtSecurityTokenHandler().WriteToken(token);
		}
	}
}
