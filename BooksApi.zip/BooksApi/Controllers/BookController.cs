﻿using BooksApi.Data;
using BooksApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BooksApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class BookController : ControllerBase
	{
		private readonly AppDbContext _context;

		public BookController(AppDbContext context)
		{
			_context = context;
		}

		// Retrieve all books
		
		[HttpGet]
		public async Task<IActionResult> GetAllBooks()
		{
			var books = await _context.Books.ToListAsync();
			return Ok(books);
		}

		// Retrieve a single book by ISBN
		[HttpGet("{isbn}")]
		public async Task<IActionResult> GetBookByISBN(string isbn)
		{
			var book = await _context.Books.FirstOrDefaultAsync(b => b.ISBN == isbn);
			return book == null ? NotFound($"Book with ISBN {isbn} not found.") : Ok(book);
		}

		// Add a new book
		[HttpPost]
		public async Task<IActionResult> AddBook([FromBody] BookDto bookdto)
		{
			if (await _context.Books.AnyAsync(b => b.ISBN == bookdto.ISBN))
			{
				return Conflict($"A book with ISBN {bookdto.ISBN} already exists.");
			}

			var book = new Book
			{
				Title = bookdto.Title,
				Author = bookdto.Author,
				ISBN = bookdto.ISBN,
				Price = bookdto.Price
			};

			_context.Books.Add(book);
			await _context.SaveChangesAsync();
			return CreatedAtAction(nameof(GetBookByISBN), new { isbn = book.ISBN }, book);
		}

		// Update an existing book
		[HttpPut("{isbn}")]
		public async Task<IActionResult> UpdateBook(string isbn, [FromBody] BookDto book)
		{
			if (isbn != book.ISBN)
			{
				return BadRequest("ISBN in the URL and request body must match.");
			}

			var existingBook = await _context.Books.FirstOrDefaultAsync(b => b.ISBN == isbn);
			if (existingBook == null)
			{
				return NotFound($"Book with ISBN {isbn} not found.");
			}

			existingBook.Title = book.Title;
			existingBook.Author = book.Author;
			existingBook.Price = book.Price;

			_context.Books.Update(existingBook);
			await _context.SaveChangesAsync();
			return NoContent();
		}

		// Delete a book by ISBN
		[HttpDelete("{isbn}")]
		public async Task<IActionResult> DeleteBook(string isbn)
		{
			var book = await _context.Books.FirstOrDefaultAsync(b => b.ISBN == isbn);
			if (book == null)
			{
				return NotFound($"Book with ISBN {isbn} not found.");
			}

			_context.Books.Remove(book);
			await _context.SaveChangesAsync();
			return NoContent();
		}
	}
}
