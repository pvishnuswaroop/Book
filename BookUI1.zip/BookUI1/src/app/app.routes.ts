import { Routes } from '@angular/router';
import { BookComponent } from './Components/book/book.component';
import { LoginComponent } from './Components/login/login.component';

export const routes: Routes = [

    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'book',
        component: BookComponent
    },
];
