import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginModel } from '../Models/Login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  apiUrl: string ="https://localhost:7283/api/Auth/login"

  constructor(private http:HttpClient) { }


  onLogin(obj:LoginModel){
    return this.http.post(this.apiUrl, obj )
  }
}
