import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BookModel } from '../Models/Book';

@Injectable({
  providedIn: 'root',
})
export class BookService {
  private apiUrl = 'https://localhost:7283/api/book'; // Adjust based on your backend URL.

  constructor(private http: HttpClient) {}

  getBook(): Observable<BookModel[]> {
    return this.http.get<BookModel[]>(this.apiUrl);
  }

  onSaveBook(book: BookModel): Observable<any> {
    return this.http.post(this.apiUrl, book);
  }

  onUpdateBook(book: BookModel): Observable<any> {
    return this.http.put(`${this.apiUrl}/${book.isbn}`, book); // Corrected to use 'isbn'
  }
  
  onDeleteBook(isbn: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${isbn}`); // Corrected to use 'isbn'
  }
  
}
