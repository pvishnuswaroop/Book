import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BookModel } from '../../Models/Book';
import { BookService } from '../../Services/book.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-book',
  imports: [FormsModule, CommonModule],
  templateUrl: './book.component.html',
  styleUrl: './book.component.scss'
})
export class BookComponent implements OnInit {

  bookList: BookModel[] = [];
  bookObj: BookModel = new BookModel();
  bookSrv = inject(BookService);

  ngOnInit(): void {
    this.getBook();
  }

  getBook() {
    this.bookSrv.getBook().subscribe((result: any) => {
      return this.bookList = result;
    })
  }

  onEdit(data: BookModel){
    this.bookObj = data;
  }

  onSaveBook(){
    this.bookSrv.onSaveBook(this.bookObj).subscribe((result:any)=>{
      alert("Book Saved Successfully");
      this.getBook();
    })
  }

  onUpdateBook(){
    this.bookSrv.onUpdateBook(this.bookObj).subscribe((result:any)=>{
      alert("Book Updated Successfully");
      this.getBook();
    })
  }

  deleteAsset(isbn: string) {  // Change parameter to string
    const isDelete = confirm("Are you sure you want to delete the Book?");
    if (isDelete) {
      this.bookSrv.onDeleteBook(isbn).subscribe((result: any) => {
        alert("Book Deleted Successfully");
        this.getBook();
      });
    }
  }
  }

