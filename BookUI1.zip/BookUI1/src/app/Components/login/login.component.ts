import { Component, inject } from '@angular/core';
import { LoginModel } from '../../Models/Login';
import { LoginService } from '../../Services/login.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {

  loginObj: LoginModel  = new LoginModel();
  loginSrv= inject (LoginService)
  router = inject(Router);

  onLogin(){
    this.loginSrv.onLogin(this.loginObj).subscribe((result:any)=>{
      alert("Logged in Successfully ")
      localStorage.setItem('jwtToken',result.token)
      this.router.navigateByUrl('book')

    })
  }
}
