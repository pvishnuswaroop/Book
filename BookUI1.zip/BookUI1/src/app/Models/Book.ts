export class BookModel {
  isbn: string = '';  // Default empty string
  title: string = ''; // Default empty string
  author: string = ''; // Default empty string
  price: number = 0;   // Default to 0

  constructor(isbn: string = '', title: string = '', author: string = '', price: number = 0) {
    this.isbn = isbn;
    this.title = title;
    this.author = author;
    this.price = price;
  }
}
