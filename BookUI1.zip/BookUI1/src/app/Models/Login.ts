export class LoginModel {
    username: string;
    password: string;

    constructor(){
      this.username="";
      this.password="";

    }
  }
  